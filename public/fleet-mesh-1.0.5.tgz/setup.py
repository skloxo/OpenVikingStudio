#!/usr/bin/env python3
# Copyright (c) 2026 Beijing Volcano Engine Technology Co., Ltd.
# SPDX-License-Identifier: AGPL-3.0
"""
OpenViking Fleet Mesh Plugin Installer (v1.0.1).
Antigravity IDE 官方标准自举向导：提供 2 个卫星集群巡检与同频工具的解耦部署。
支持拓扑自适应、宿主注册表写入与双轨 MCP 联动。
"""

import argparse
import json
import os
import shutil
import stat
import sys
import urllib.request
from pathlib import Path

# SECTION: Windows UTF-8 Stdio Safeguard
if sys.platform == "win32":
    try:
        sys.stdin.reconfigure(encoding="utf-8", errors="replace")
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

PLUGIN_NAME = "fleet-mesh"
PLUGIN_SRC_DIR = Path(__file__).resolve().parent
GEMINI_CONFIG_DIR = Path.home() / ".gemini" / "config"
DEFAULT_TARGET_DIR = GEMINI_CONFIG_DIR / "plugins" / PLUGIN_NAME


def get_plugin_version() -> str:
    pj = PLUGIN_SRC_DIR / "plugin.json"
    if pj.exists():
        try:
            with open(pj, "r", encoding="utf-8") as f:
                return json.load(f).get("version", "1.0.2")
        except Exception:
            pass
    return "1.0.2"


PLUGIN_VERSION = get_plugin_version()


def resolve_best_api(preferred_api: str = "") -> str:
    if preferred_api and str(preferred_api).strip():
        return str(preferred_api).strip().rstrip("/")
    local_api = "http://127.0.0.1:1933"
    try:
        req = urllib.request.Request(f"{local_api}/health")
        with urllib.request.urlopen(req, timeout=0.6) as resp:
            if resp.status == 200:
                return local_api
    except Exception:
        pass
    env_api = os.environ.get("OPENVIKING_API", "").strip()
    return env_api.rstrip("/") if env_api else "https://vk.tide.red"


def register_in_ide_config(plugin_name: str, version: str):
    cfg_file = GEMINI_CONFIG_DIR / "config.json"
    if not cfg_file.exists():
        return
    try:
        with open(cfg_file, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        plugins = cfg.get("plugins", {})
        plugins[plugin_name] = {
            "installedFrom": {
                "id": f"openviking/plugin/{plugin_name}",
                "marketplace": "openviking-marketplace",
                "version": version
            }
        }
        cfg["plugins"] = plugins
        with open(cfg_file, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        print(f"  ✔ 成功在 IDE config.json 注册表登记 {plugin_name} (v{version})")
    except Exception as e:
        print(f"  ⚠️ 注册 IDE config.json 失败: {e}")


def sync_mcp_fleet(api: str, key: str, target_dir: Path):
    candidate_scripts = [
        Path.home() / "Desktop" / "coding" / "OpenVikingStudio" / "mcp-openviking" / "mcp_openviking_server.py",
        PLUGIN_SRC_DIR.parent.parent / "mcp-openviking" / "mcp_openviking_server.py",
    ]
    server_script = ""
    for c in candidate_scripts:
        if c.exists():
            server_script = str(c).replace("\\", "/")
            break
    if not server_script:
        server_script = "C:/Users/Skl/Desktop/coding/OpenVikingStudio/mcp-openviking/mcp_openviking_server.py"

    py_cmd = sys.executable.replace("\\", "/")
    p_mcp = {
        "mcpServers": {
            "fleet-mesh": {
                "command": py_cmd,
                "args": [server_script, "--mode=fleet"],
                "env": {
                    "OPENVIKING_API": api,
                    "OPENVIKING_API_KEY": key,
                    "OPENVIKING_MCP_MODE": "fleet",
                    "PYTHONIOENCODING": "utf-8"
                }
            }
        }
    }
    with open(target_dir / "mcp_config.json", "w", encoding="utf-8") as f:
        json.dump(p_mcp, f, indent=2, ensure_ascii=False)

    g_mcp_path = GEMINI_CONFIG_DIR / "mcp_config.json"
    if g_mcp_path.exists():
        try:
            with open(g_mcp_path, "r", encoding="utf-8") as f:
                g_data = json.load(f)
            servers = g_data.get("mcpServers", {})
            servers["fleet-mesh"] = {
                "command": py_cmd,
                "args": [server_script, "--mode=fleet"],
                "env": {
                    "OPENVIKING_API": api,
                    "OPENVIKING_API_KEY": key,
                    "OPENVIKING_MCP_MODE": "fleet",
                    "OPENVIKING_ACTOR_PEER": "antigravity@2080Ti",
                    "PYTHONIOENCODING": "utf-8"
                }
            }
            g_data["mcpServers"] = servers
            with open(g_mcp_path, "w", encoding="utf-8") as f:
                json.dump(g_data, f, indent=2, ensure_ascii=False)
            print("  ✔ 全局 mcp_config.json fleet-mesh 条目联动完成")
        except Exception as e:
            print(f"  ⚠️ 全局 mcp_config.json 联动失败: {e}")


def install_plugin(target_dir: Path, api: str, key: str):
    print(f"📦 正在准备安装 OpenViking 卫星同频插件 (v{PLUGIN_VERSION}) 至: {target_dir}")
    target_dir.mkdir(parents=True, exist_ok=True)

    copy_items = ["skills", "plugin.json", "mcp_config.json", "setup.py"]
    for item_name in copy_items:
        src = PLUGIN_SRC_DIR / item_name
        dst = target_dir / item_name
        if src.exists():
            if src.is_dir():
                shutil.copytree(src, dst, dirs_exist_ok=True)
            else:
                shutil.copy2(src, dst)

    config_data = {
        "api_url": api,
        "api_key": key,
        "verified_user": "fleet_master"
    }
    cfg_file = target_dir / "config.json"
    with open(cfg_file, "w", encoding="utf-8") as f:
        json.dump(config_data, f, indent=2, ensure_ascii=False)
        f.write("\n")
    try:
        os.chmod(cfg_file, stat.S_IRUSR | stat.S_IWUSR)
    except Exception:
        pass
    print("  ✔ config.json 凭据落盘完成 (0600)")

    register_in_ide_config(PLUGIN_NAME, PLUGIN_VERSION)
    sync_mcp_fleet(api, key, target_dir)

    print(f"🎉 OpenViking 卫星同频插件标准自举完成！(fleet-mesh 2 Tools 已生效)")


def main():
    parser = argparse.ArgumentParser(description="OpenViking 卫星同频插件标准自举安装向导")
    parser.add_argument("--install", action="store_true", help="安装插件至 Antigravity 插件目录")
    parser.add_argument("--target", type=str, default="", help="指定安装目标目录")
    parser.add_argument("--api", type=str, default="", help="OpenViking API 地址")
    parser.add_argument("--key", type=str, default="", help="OpenViking API Key")
    args = parser.parse_args()

    target_dir = Path(args.target).resolve() if args.target else DEFAULT_TARGET_DIR
    api = resolve_best_api(args.api)
    key = args.key or os.environ.get("OPENVIKING_API_KEY", "")
    if not key:
        cfg = target_dir / "config.json"
        if cfg.exists():
            try:
                with open(cfg, "r", encoding="utf-8") as f:
                    key = json.load(f).get("api_key", "")
            except Exception:
                pass

    install_plugin(target_dir, api, key)


if __name__ == "__main__":
    main()
