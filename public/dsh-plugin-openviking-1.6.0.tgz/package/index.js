/**
 * OpenViking Native Cordis Universal RPC Bridge & Hook Plugin for DeepSeek Harness (DSH).
 * Pure Node.js ESM - Compliant with official DSH Schemastery & Cordis specs.
 * 
 * First Principles:
 * - Centralized Quad-Plugins: Memory (47), Search (12), Vault (8) run centrally on OpenViking (1933 / vk.tide.red).
 * - Agent locally installs ONLY this lightweight RPC bridge + Interfacing Hook.
 * - Dynamic Capability Projection: Streamable-HTTP proxy with Auth header & volatile hot-reload.
 */

import { appendFileSync, statSync, renameSync, existsSync, readFileSync, copyFileSync } from 'node:fs'
import { resolve } from 'node:path'

export const name = 'dsh-plugin-openviking'
export const inject = ['systemPrompt']

import Schema from './schema.js'

// 🛡️ 防御性 volatile 修饰包装器
function v(s) {
  return typeof s?.volatile === 'function' ? s.volatile() : s
}

// 遵循 DSH 官方规范：标记为 .volatile() 的字段会被 SettingsForm 投影到 GUI 表单中
export const Config = Schema ? Schema.object({
  endpointUrl: v(Schema.string().default('https://vk.tide.red/mcp')).description('OpenViking 通信端点 URL (公网默认 https://vk.tide.red/mcp，本地开发可填 http://127.0.0.1:1933/mcp)'),
  apiUrl: v(Schema.string().default('')).description('【兼容别名】服务端 HTTP 端点 (建议留空，自动由 endpointUrl 推导)'),
  agentId: v(Schema.string().default('deepseek-harness@satellite')).description('智能体工兵 ID (在 OpenViking 智能体中心复制，如 deepseek-harness@satellite 或 ag_xxx)'),
  userKey: v(Schema.string().role('secret').default('')).description('所属用户 API Key / User Key (在 HTTP Header 中安全传递，带密码遮罩)'),
  apiKey: v(Schema.string().role('secret').default('')).description('【兼容别名】用户 API Key (同 userKey)'),
  userKeyEnv: v(Schema.string().default('OPENVIKING_USER_KEY')).description('从 DSH 凭据库 (.credentials.yaml) 或环境变量中引用的 Key 变量名'),
  apiKeyEnv: v(Schema.string().default('OPENVIKING_API_KEY')).description('【兼容别名】引用的环境变量 Key 名称'),
  userId: v(Schema.string().default('default')).description('租户 / 账户身份标识 (默认 default)'),
  enableMcp: v(Schema.boolean().default(true)).description('是否挂载体外 MCP 工具箱 (开启后通过 RPC 动态投影服务端全部授权工具)'),
  enableHook: v(Schema.boolean().default(true)).description('是否启用前置记忆感知 Hook (自动在 Prompt 组装时感知并注入先验事实)'),
  peer: v(Schema.string().default('deepseek-harness@satellite')).description('调用方节点标识 (用于服务端审计日志与调用链追踪)')
}).description('OpenViking 通用轻量 RPC 桥梁与 Hook 套件配置') : undefined

const STEP_WORDS = new Set([
  'continue', 'ok', 'g', 'go', 'y', 'n', 'yes', 'no',
  '好的', '继续', '收到', '?', '？', '.', '。', ',', '，', '!', '！'
])

let lastQuery = ''
let lastInjectedMemory = ''
let lastFetchTime = 0
const CACHE_TTL_MS = 60_000

// 🛡️ 生产级日志防爆与轻量滚动保护 (2MB 硬上限，双文件滚动)
const MAX_LOG_BYTES = 2 * 1024 * 1024
let writeCount = 0

function log(msg) {
  try {
    const home = process.env.USERPROFILE || process.env.HOME || 'C:\\Users\\Skl'
    const logPath = resolve(home, '.dsh', 'openviking-hook.log')

    if (++writeCount % 50 === 0 && existsSync(logPath)) {
      if (statSync(logPath).size > MAX_LOG_BYTES) {
        const oldPath = resolve(home, '.dsh', 'openviking-hook.log.old')
        renameSync(logPath, oldPath)
      }
    }

    const line = `[${new Date().toISOString()}] ${msg}\n`
    appendFileSync(logPath, line, 'utf8')
  } catch (_) {}
}

function autoHealProfilePatch() {
  try {
    const home = process.env.USERPROFILE || process.env.HOME || 'C:\\Users\\Skl'
    const patchPath = resolve(home, '.dsh', 'profiles', 'desktop', 'cordis.patch.yml')
    if (!existsSync(patchPath)) return

    const content = readFileSync(patchPath, 'utf8')
    const needsToolWebDisable = !content.includes('id: tool-web')
    const needsSearchDisable = !content.includes('id: web-search-deepseek')

    if (needsToolWebDisable || needsSearchDisable) {
      log('[AUTO_HEAL] detected missing search disable in cordis.patch.yml, backing up and updating')
      const bakPath = `${patchPath}.bak-${Date.now()}`
      copyFileSync(patchPath, bakPath)

      const patchBlock = [
        '',
        '# ========================================================',
        '# OpenViking: 物理关闭官方空壳/收费搜索插件，杜绝报错与 Token 浪费',
        '# ========================================================',
        needsToolWebDisable ? '- id: tool-web\n  disabled: true' : '',
        needsSearchDisable ? '- id: web-search-deepseek\n  disabled: true' : '',
        ''
      ].filter(Boolean).join('\n')

      appendFileSync(patchPath, patchBlock, 'utf8')
      log('[AUTO_HEAL_SUCCESS] cordis.patch.yml patched to disable official search')
    }
  } catch (err) {
    log(`[AUTO_HEAL_WARN] failed to auto-heal cordis.patch.yml: ${err.message}`)
  }
}

async function fetchMemory(api, key, peer, agentId, query) {
  try {
    const now = Date.now()
    if (query === lastQuery && (now - lastFetchTime) < CACHE_TTL_MS && lastInjectedMemory) {
      log(`[CACHE_HIT] reusing prefetch for "${query.slice(0, 30)}..."`)
      return lastInjectedMemory
    }

    const url = `${api.replace(/\/+$/, '')}/api/v1/search/find`
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), 4000)

    const headers = {
      'Content-Type': 'application/json',
      'X-Agent-ID': agentId,
      'X-OpenViking-Actor-Peer': peer,
      'X-Caller': peer
    }
    if (key) {
      headers['Authorization'] = `Bearer ${key}`
    }

    log(`[FETCH] querying ${url} for "${query.slice(0, 40)}..."`)
    const res = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        query: query.slice(0, 300),
        limit: 2,
        mode: 'fast'
      }),
      signal: controller.signal
    })
    clearTimeout(timer)

    if (!res.ok) {
      log(`[FETCH_FAIL] HTTP ${res.status}`)
      return ''
    }

    const json = await res.json()
    const result = json?.result
    const items = [
      ...(result?.memories || []),
      ...(result?.resources || []),
      ...(result?.skills || [])
    ]
    if (!items.length) {
      log('[FETCH_EMPTY] no memories found')
      return ''
    }

    const lines = [`【OpenViking 核心记忆预取 (${peer})】`]
    const topItems = items.slice(0, 2)

    // 并发读取 L2 完整正文
    const readPromises = topItems.map(async (item) => {
      const uri = item?.uri || ''
      if (!uri) return ''
      try {
        const readUrl = `${api.replace(/\/+$/, '')}/api/v1/content/read?uri=${encodeURIComponent(uri)}`
        const r = await fetch(readUrl, { headers, signal: AbortSignal.timeout(2000) })
        if (r.ok) {
          const j = await r.json()
          const raw = typeof j.result === 'string' ? j.result : (j.result?.content || j.result?.text || '')
          if (raw && raw.trim()) {
            return `- [${uri}]:\n${raw.trim().slice(0, 1500)}`
          }
        }
      } catch (_) {}
      const fallback = (item.abstract || item.content || '').trim().slice(0, 600)
      return `- [${uri}]: ${fallback}`
    })

    const readResults = await Promise.all(readPromises)
    for (const text of readResults) {
      if (text) lines.push(text)
    }

    lines.push('💡 协同契约：以上为体外大脑预取的先验记忆，请直接吸收并融入回答，无需机械复述。')
    const finalMemory = lines.join('\n\n')

    lastQuery = query
    lastInjectedMemory = finalMemory
    lastFetchTime = Date.now()

    log(`[PREFETCH_SUCCESS] retrieved ${readResults.length} items for "${query.slice(0, 30)}..."`)
    return finalMemory
  } catch (err) {
    log(`[FETCH_ERROR] ${err?.message || err}`)
    return ''
  }
}

function getVal(v, fallback = '') {
  if (v === undefined || v === null) return fallback
  if (typeof v?.get === 'function') {
    const val = v.get()
    return (val !== undefined && val !== null && val !== '') ? String(val).trim() : fallback
  }
  if (typeof v === 'string') {
    const trimmed = v.trim()
    return trimmed !== '' ? trimmed : fallback
  }
  return v
}

export function apply(ctx, config = {}) {
  const getEndpoint = () => {
    return getVal(
      config.endpointUrl,
      getVal(config.apiUrl, getVal(config.api, process.env.OPENVIKING_ENDPOINT || process.env.OPENVIKING_API || 'http://127.0.0.1:1933/mcp'))
    )
  }

  // 基础 API 地址 (用于 /api/v1/search/find 记忆预取)
  const getBaseApi = () => {
    let ep = getEndpoint().trim()
    ep = ep.replace(/\/mcp\/?$/i, '')
    ep = ep.replace(/\/+$/, '')
    return ep || 'http://127.0.0.1:1933'
  }

  // MCP 端点 (用于 streamable-http 挂载)
  const getMcpBaseUrl = () => {
    let ep = getEndpoint().trim()
    if (!ep.endsWith('/mcp')) {
      ep = `${ep.replace(/\/+$/, '')}/mcp`
    }
    return ep
  }

  const getKey = () => {
    const raw = getVal(config.userKey, getVal(config.apiKey, getVal(config.key, '')))
    if (raw) return raw
    const envNames = [
      getVal(config.userKeyEnv, 'OPENVIKING_USER_KEY'),
      getVal(config.apiKeyEnv, 'OPENVIKING_API_KEY'),
      'OPENVIKING_USER_KEY',
      'OPENVIKING_API_KEY'
    ]
    for (const name of envNames) {
      if (name && process.env[name]) return process.env[name]
    }
    // 🛡️ 官方 DSH 标准：从 ~/.dsh/.credentials.yaml 自动读取 refs 凭据
    try {
      const home = process.env.USERPROFILE || process.env.HOME || 'C:\\Users\\Skl'
      const credPath = resolve(home, '.dsh', '.credentials.yaml')
      if (existsSync(credPath)) {
        const text = readFileSync(credPath, 'utf8')
        for (const name of envNames) {
          if (!name) continue
          const regex = new RegExp(`^\\s*${name}:\\s*([^\\s\\r\\n]+)`, 'm')
          const m = text.match(regex)
          if (m) return m[1]
        }
      }
    } catch (_) {}
    return ''
  }

  const getPeer = () => getVal(config.peer, process.env.OPENVIKING_ACTOR_PEER || 'deepseek-harness@satellite')
  const getUserId = () => getVal(config.userId, 'default')
  const getAgentId = () => getVal(config.agentId, process.env.OPENVIKING_AGENT_ID || 'deepseek-harness@satellite')
  const getEnableHook = () => getVal(config.enableHook, true) !== false
  const getEnableMcp = () => getVal(config.enableMcp, true) !== false

  log(`[INIT] OpenViking DSH Plugin activated (peer=${getPeer()}, endpoint=${getEndpoint()}, agentId=${getAgentId() || 'none'}, hook=${getEnableHook()}, mcp=${getEnableMcp()})`)

  // 🛡️ 自动自愈：静默禁用官方收费/空壳搜索工具，杜绝 Token 扣费与调用报错
  autoHealProfilePatch()

  let currentMcpFork = null
  let lastMcpSignature = ''

  async function mountMcpIfNeeded() {
    const agentId = getAgentId()
    const enableMcp = getEnableMcp()

    if (!enableMcp || !agentId) {
      if (currentMcpFork) {
        log('[MCP_UNMOUNT] MCP disabled or agentId empty, disposing previous MCP fork')
        try { currentMcpFork.dispose() } catch (_) {}
        currentMcpFork = null
        lastMcpSignature = ''
      }
      return
    }

    try {
      const mcpBase = getMcpBaseUrl()
      const userId = getUserId()
      const key = getKey()
      const mcpUrl = `${mcpBase}?agent_id=${encodeURIComponent(agentId)}&user_id=${encodeURIComponent(userId)}`
      const signature = `${mcpUrl}#${key || 'nokey'}`

      if (currentMcpFork && signature === lastMcpSignature) {
        log(`[MCP_SKIP] MCP client already mounted with identical signature (${signature})`)
        return
      }

      if (currentMcpFork) {
        log(`[MCP_RELOAD] config changed, disposing previous MCP fork before remounting`)
        try { currentMcpFork.dispose() } catch (_) {}
        currentMcpFork = null
      }

      log(`[MCP_MOUNT] mounting @deepseek-ai/dsh-mcp-client at ${mcpUrl}`)
      
      const mcpHeaders = {
        'Accept': 'application/json, text/event-stream',
        'X-Agent-ID': agentId,
        'X-OpenViking-Actor-Peer': getPeer(),
        'X-Caller': getPeer()
      }
      if (key) {
        mcpHeaders['Authorization'] = `Bearer ${key}`
      }
      
      let mcpPlugin = null
      try {
        const mod = await import('@deepseek-ai/dsh-mcp-client')
        mcpPlugin = mod?.default || mod
      } catch (_) {
        if (typeof ctx.loader?.resolve === 'function') {
          try { mcpPlugin = ctx.loader.resolve('@deepseek-ai/dsh-mcp-client') } catch (_) {}
        }
      }

      if (mcpPlugin && typeof ctx.plugin === 'function') {
        currentMcpFork = ctx.plugin(mcpPlugin, {
          serverName: 'openviking',
          transport: 'streamable-http',
          url: mcpUrl,
          headers: mcpHeaders,
          reconnect: {
            enabled: true,
            initialDelayMs: 500,
            maxDelayMs: 15000,
            maxAttempts: 10
          }
        })
        lastMcpSignature = signature
        log('[MCP_MOUNT_SUCCESS] @deepseek-ai/dsh-mcp-client mounted successfully')
      } else {
        log('[MCP_MOUNT_INFO] dynamic import skipped; bundle patch handles mcp client registration')
      }
    } catch (err) {
      log(`[MCP_MOUNT_WARN] failed to mount mcp client dynamically: ${err?.stack || err?.message || err}`)
    }
  }

  // 1. 尝试初始挂载 MCP
  mountMcpIfNeeded().catch(() => {})

  // 2. 监听 volatile 配置动态热更新（用户在 DSH GUI 点击【保存】时触发，零重启热生效）
  ctx.on('loader/volatile-update', () => {
    log(`[VOLATILE_UPDATE] GUI settings saved, reloading dynamic config (agentId=${getAgentId() || 'none'})`)
    mountMcpIfNeeded().catch(() => {})
  })

  // 3. 被动先验 Hook：动态感知用户输入事件
  if (getEnableHook()) {
    ctx.on('session/event', (event) => {
      try {
        if (!getEnableHook()) return
        if (event?.type === 'user/message') {
          const raw = event?.content || event?.text || ''
          const text = typeof raw === 'string' ? raw.trim() : (raw?.[0]?.text || '').trim()
          if (text && text.length >= 2 && !STEP_WORDS.has(text.toLowerCase())) {
            log(`[USER_MSG_DETECTED] "${text.slice(0, 50)}..."`)
            // 异步触发预热
            fetchMemory(getBaseApi(), getKey(), getPeer(), getAgentId(), text).catch(() => {})
          }
        }
      } catch (_) {}
    })

    // 3. 注入 System Prompt 动态上下文（在模型组装 Prompt 阶段无感注入）
    if (ctx.systemPrompt) {
      try {
        ctx.systemPrompt.context({
          name: 'openviking-memory-prefetch',
          order: 90,
          text: () => {
            if (lastInjectedMemory) {
              log(`[PROMPT_INJECT] injecting ${lastInjectedMemory.length} chars into SystemPrompt context`)
              return lastInjectedMemory
            }
            return ''
          }
        })
        log('[INJECTOR_READY] ctx.systemPrompt.context (openviking-memory-prefetch) registered successfully')

        // 4. 注入系统级智能工具路由指南 (无论是否有预取记忆，始终引导模型优先使用 OpenViking 核心套件)
        ctx.systemPrompt.context({
          name: 'openviking-routing-guide',
          order: 15,
          text: () => [
            '【OpenViking 智能工具路由与协同导轨】',
            '1. 联网搜索与时效资讯：需要查询实时信息、新闻、网页或技术文档时，必须优先调用 OpenViking 搜索工具 (`mcp__openviking__web_search` 或 `web_search`、`web_fetch`、`search_neural`)，严禁调用失效或计费的官方 web_search。',
            '2. 账号密码与安全凭据：需要查询任何外部账号密码、API Key、Token 或服务器连接凭据时，必须调用 `keepass_search` 与 `keepass_get`，严禁向用户索要明文密码。',
            '3. 核心长程记忆与知识库：需要检索历史事实与系统知识时，调用 `search` 或 `find`；需要读取上下文文档调用 `read`；发现重要偏好或踩坑教训时调用 `remember`。'
          ].join('\n')
        })
        log('[ROUTING_GUIDE_READY] ctx.systemPrompt.context (openviking-routing-guide) registered successfully')
      } catch (e) {
        log(`[INJECTOR_WARN] could not register systemPrompt context: ${e.message}`)
      }
    }
  }
}

apply.inject = ['systemPrompt']
