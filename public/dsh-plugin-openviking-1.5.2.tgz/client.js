/**
 * client.js - OpenViking DSH Client Plugin
 * 纯原生 React (由 DSH 宿主提供)，无外部打包依赖。
 * 向 DSH Web 客户端注册：
 * 1. plugins.bundle.config: 插件包主详情页顶部的【OpenViking 核心协同配置】座舱面板；
 * 2. plugins.row.config: 单组件行（openviking）的专属配置面板；
 * 3. conversation.composer.dock: 对话输入框上方体外大脑状态指示微胶囊。
 */

window.__ModuleLoader__.load({
  id: 'dsh-plugin-openviking',
  factory(require) {
    const React = require('react');
    const h = React.createElement;
    const { useState, useEffect, useCallback } = React;

    const STORAGE_KEY = 'openviking_dsh_config';

    function loadSavedConfig() {
      try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) return JSON.parse(raw);
      } catch (_) {}
      return {
        endpointUrl: 'http://127.0.0.1:1933/mcp',
        agentId: 'deepseek-harness@satellite',
        userKey: '',
        peer: 'deepseek-harness@satellite',
        enableMcp: true,
        enableHook: true,
      };
    }

    function saveConfig(cfg) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(cfg));
      } catch (_) {}
    }

    // 配置表单主组件
    function OpenVikingConfigPanel(props) {
      const [config, setConfig] = useState(loadSavedConfig);
      const [showKey, setShowKey] = useState(false);
      const [testStatus, setTestStatus] = useState(null); // { ok: boolean, msg: string }
      const [testing, setTesting] = useState(false);
      const [savedToast, setSavedToast] = useState(false);

      const handleChange = (field, value) => {
        setConfig((prev) => ({ ...prev, [field]: value }));
      };

      const handleTest = async () => {
        setTesting(true);
        setTestStatus(null);
        try {
          let base = (config.endpointUrl || '').trim();
          base = base.replace(/\/mcp\/?$/i, '').replace(/\/+$/, '');
          if (!base) base = 'http://127.0.0.1:1933';

          const start = Date.now();
          const headers = { 'Content-Type': 'application/json' };
          if (config.userKey) {
            headers['Authorization'] = `Bearer ${config.userKey}`;
          }
          if (config.agentId) {
            headers['X-Agent-ID'] = config.agentId;
          }

          const fetchFn = typeof window !== 'undefined' && window.fetch ? window.fetch.bind(window) : fetch;
          const res = await fetchFn(`${base}/health`, {
            headers,
            signal: AbortSignal.timeout(3000),
          });
          const latency = Date.now() - start;

          if (res.ok) {
            const data = await res.json();
            setTestStatus({
              ok: true,
              msg: `连接成功 (v${data.version || '1.7'}) · 延迟 ${latency}ms · 认证: ${data.auth_mode || 'trusted'}`,
            });
          } else {
            setTestStatus({
              ok: false,
              msg: `连接失败: HTTP ${res.status} ${res.statusText}`,
            });
          }
        } catch (err) {
          setTestStatus({
            ok: false,
            msg: `连接不可达: ${err.message || '网络超时或服务端未启动'}`,
          });
        } finally {
          setTesting(false);
        }
      };

      const handleSave = () => {
        saveConfig(config);
        setSavedToast(true);
        const timerFn = typeof window !== 'undefined' && window.setTimeout ? window.setTimeout.bind(window) : setTimeout;
        timerFn(() => setSavedToast(false), 2500);

        // 如果宿主提供了 form.mutate，尝试回写
        if (props?.form?.mutate) {
          try {
            props.form.mutate([
              { op: 'replace', path: '/endpointUrl', value: config.endpointUrl },
              { op: 'replace', path: '/agentId', value: config.agentId },
              { op: 'replace', path: '/userKey', value: config.userKey },
            ]);
          } catch (_) {}
        }
      };

      return h(
        'div',
        {
          style: {
            background: 'var(--dsw-alias-surface-l1, #1e1e24)',
            border: '1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.1))',
            borderRadius: '8px',
            padding: '16px',
            marginBottom: '16px',
            fontFamily: 'system-ui, -apple-system, sans-serif',
            fontSize: '13px',
            color: 'var(--dsw-alias-label-primary, #e2e8f0)',
          },
        },
        // 头部
        h(
          'div',
          {
            style: {
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: '14px',
              borderBottom: '1px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.06))',
              paddingBottom: '10px',
            },
          },
          h(
            'div',
            { style: { display: 'flex', alignItems: 'center', gap: '8px' } },
            h('span', { style: { fontSize: '16px' } }, '🧠'),
            h(
              'span',
              { style: { fontWeight: '600', fontSize: '14px', letterSpacing: '-0.01em' } },
              'OpenViking 体外大脑连接配置'
            ),
            h(
              'span',
              {
                style: {
                  fontSize: '11px',
                  background: 'rgba(6, 182, 212, 0.15)',
                  color: '#22d3ee',
                  border: '1px solid rgba(6, 182, 212, 0.3)',
                  padding: '1px 6px',
                  borderRadius: '4px',
                  fontFamily: 'monospace',
                },
              },
              'SSOT'
            )
          ),
          h(
            'button',
            {
              type: 'button',
              onClick: handleTest,
              disabled: testing,
              style: {
                background: 'rgba(255,255,255,0.06)',
                border: '1px solid rgba(255,255,255,0.15)',
                color: 'var(--dsw-alias-label-primary, #f1f5f9)',
                padding: '4px 10px',
                borderRadius: '5px',
                fontSize: '12px',
                cursor: testing ? 'not-allowed' : 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
              },
            },
            testing ? '探测中...' : '⚡ 测试连通性'
          )
        ),
        // 测试结果状态条
        testStatus
          ? h(
              'div',
              {
                style: {
                  padding: '8px 12px',
                  borderRadius: '6px',
                  marginBottom: '14px',
                  fontSize: '12px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  background: testStatus.ok
                    ? 'rgba(6, 182, 212, 0.12)'
                    : 'rgba(244, 63, 94, 0.12)',
                  border: `1px solid ${
                    testStatus.ok ? 'rgba(6, 182, 212, 0.3)' : 'rgba(244, 63, 94, 0.3)'
                  }`,
                  color: testStatus.ok ? '#22d3ee' : '#fb7185',
                },
              },
              testStatus.ok ? '✅ ' : '❌ ',
              testStatus.msg
            )
          : null,
        // 表单字段列表
        h(
          'div',
          { style: { display: 'flex', flexDirection: 'column', gap: '12px' } },
          // 字段 1: endpointUrl
          h(
            'div',
            null,
            h(
              'label',
              {
                style: {
                  display: 'block',
                  fontSize: '12px',
                  fontWeight: '500',
                  marginBottom: '4px',
                  color: 'var(--dsw-alias-label-secondary, #94a3b8)',
                },
              },
              '通信端点 URL (endpointUrl) *'
            ),
            h('input', {
              type: 'text',
              value: config.endpointUrl,
              onChange: (e) => handleChange('endpointUrl', e.target.value),
              placeholder: 'http://127.0.0.1:1933/mcp',
              style: {
                width: '100%',
                boxSizing: 'border-box',
                padding: '7px 10px',
                fontSize: '13px',
                fontFamily: 'monospace',
                borderRadius: '6px',
                border: '1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.15))',
                background: 'var(--dsw-alias-surface-l0, rgba(0,0,0,0.25))',
                color: 'var(--dsw-alias-label-primary, #f8fafc)',
              },
            }),
            h(
              'div',
              {
                style: {
                  fontSize: '11px',
                  color: 'var(--dsw-alias-label-tertiary, #64748b)',
                  marginTop: '3px',
                },
              },
              '本地默认：http://127.0.0.1:1933/mcp；远程节点可配置公网反代或私网 IPv6 端点'
            )
          ),
          // 字段 2: agentId
          h(
            'div',
            null,
            h(
              'label',
              {
                style: {
                  display: 'block',
                  fontSize: '12px',
                  fontWeight: '500',
                  marginBottom: '4px',
                  color: 'var(--dsw-alias-label-secondary, #94a3b8)',
                },
              },
              '智能体工兵 ID (agentId) *'
            ),
            h('input', {
              type: 'text',
              value: config.agentId,
              onChange: (e) => handleChange('agentId', e.target.value),
              placeholder: 'deepseek-harness@satellite 或 ag_xxx',
              style: {
                width: '100%',
                boxSizing: 'border-box',
                padding: '7px 10px',
                fontSize: '13px',
                fontFamily: 'monospace',
                borderRadius: '6px',
                border: '1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.15))',
                background: 'var(--dsw-alias-surface-l0, rgba(0,0,0,0.25))',
                color: 'var(--dsw-alias-label-primary, #f8fafc)',
              },
            }),
            h(
              'div',
              {
                style: {
                  fontSize: '11px',
                  color: 'var(--dsw-alias-label-tertiary, #64748b)',
                  marginTop: '3px',
                },
              },
              '在 OpenViking 智能体中心（Agent Hub）卡片上复制对应的工兵 ID'
            )
          ),
          // 字段 3: userKey
          h(
            'div',
            null,
            h(
              'label',
              {
                style: {
                  display: 'block',
                  fontSize: '12px',
                  fontWeight: '500',
                  marginBottom: '4px',
                  color: 'var(--dsw-alias-label-secondary, #94a3b8)',
                },
              },
              '用户 API Key / User Key (userKey)'
            ),
            h(
              'div',
              { style: { display: 'flex', gap: '8px' } },
              h('input', {
                type: showKey ? 'text' : 'password',
                value: config.userKey,
                onChange: (e) => handleChange('userKey', e.target.value),
                placeholder: '留空则从环境变量或 .credentials.yaml 读取',
                style: {
                  flex: 1,
                  boxSizing: 'border-box',
                  padding: '7px 10px',
                  fontSize: '13px',
                  fontFamily: 'monospace',
                  borderRadius: '6px',
                  border: '1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.15))',
                  background: 'var(--dsw-alias-surface-l0, rgba(0,0,0,0.25))',
                  color: 'var(--dsw-alias-label-primary, #f8fafc)',
                },
              }),
              h(
                'button',
                {
                  type: 'button',
                  onClick: () => setShowKey(!showKey),
                  style: {
                    background: 'transparent',
                    border: '1px solid rgba(255,255,255,0.15)',
                    color: 'var(--dsw-alias-label-secondary, #94a3b8)',
                    padding: '0 10px',
                    borderRadius: '6px',
                    cursor: 'pointer',
                    fontSize: '12px',
                  },
                },
                showKey ? '隐藏' : '显示'
              )
            ),
            h(
              'div',
              {
                style: {
                  fontSize: '11px',
                  color: 'var(--dsw-alias-label-tertiary, #64748b)',
                  marginTop: '3px',
                },
              },
              '可留空，插件将自动检索 OPENVIKING_USER_KEY 环境变量或本地凭据中枢'
            )
          )
        ),
        // 底部保存条
        h(
          'div',
          {
            style: {
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: '16px',
              paddingTop: '12px',
              borderTop: '1px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.06))',
            },
          },
          h(
            'div',
            { style: { fontSize: '12px', color: '#22d3ee', display: 'flex', alignItems: 'center', gap: '4px' } },
            savedToast ? '✨ 配置已成功保存并即时生效' : ''
          ),
          h(
            'button',
            {
              type: 'button',
              onClick: handleSave,
              style: {
                background: '#0891b2',
                color: '#ffffff',
                border: 'none',
                padding: '6px 16px',
                borderRadius: '6px',
                fontSize: '13px',
                fontWeight: '600',
                cursor: 'pointer',
                boxShadow: '0 1px 3px rgba(0,0,0,0.3)',
              },
            },
            '保存配置'
          )
        )
      );
    }

    return {
      inject: ['slots'],
      apply(ctx) {
        // 1. 注册到 Bundle 详情页顶部
        ctx.slots.inject('plugins.bundle.config', () =>
          ctx.slots.register(
            {
              name: 'plugins.bundle.config',
              key: 'dsh-plugin-openviking',
            },
            OpenVikingConfigPanel
          )
        );

        // 2. 注册到组件行点击进入的详情页
        ctx.slots.inject('plugins.row.config', () =>
          ctx.slots.register(
            {
              name: 'plugins.row.config',
              key: 'dsh-plugin-openviking#openviking',
            },
            OpenVikingConfigPanel
          )
        );
      },
    };
  },
});
