#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
拦截 PreToolUse 事件，执行六重守卫：
1. Task id 与实体 uid 异构纠偏守卫；
2. 空主键删除高危操作物理拦截；
3. Task / Project 异构 priority 枚举纠偏拦截；
4. Task / Project / Goal 异构 status 与 horizon 枚举纠偏拦截；
5. 核心标签四正交与时间/动作标签（today/someday/汇报）零滥用拦截；
6. 任务标题脱水守卫（严禁中括号前缀、严禁软编号伪编码、严禁重复项目名前缀）。
严格遵循 OpenViking 插件中心四位一体与芒格逆向铁律：
- 纯标准库隔离 (-X utf8 -E -s -S)，零第三方依赖，冷启动 <= 30ms；
- sys.stdin.readline() 单行流式读取，杜绝父子进程管道死锁；
- sys.stdout.buffer 原生直写 UTF-8 字节，封闭 stderr；
- 全流程 BaseException 捕获兜底，退出码恒为 0 (Fail-Open)。
"""

from __future__ import annotations

import json
import re
import sys
from typing import Any, Dict

FORBIDDEN_TAGS = {
    "today", "someday", "汇报",
    "p0", "p1", "p2", "p3", "urgent", "high", "medium", "low",
    "紧急", "高优", "高优先级", "低优先级", "重要",
    "todo", "done", "in_progress", "待办", "进行中", "已完成", "未开始",
    "工作", "个人",
}

VALID_CORE_TAGS = {"开发", "运维", "规划", "缺陷"}

VALID_TASK_STATUS = {
    "not_started", "pending", "planned", "in_progress",
    "waiting", "done", "completed", "cancelled", "archived",
}
VALID_PROJECT_STATUS = {
    "not_started", "planned", "in_progress", "waiting", "done", "cancelled",
}
VALID_TASK_PRIORITY = {"none", "low", "medium", "high"}
VALID_PROJECT_PRIORITY = {0, 1, 2, "0", "1", "2"}
VALID_GOAL_STATUS = {"active", "achieved", "paused", "dropped"}
VALID_GOAL_HORIZON = {"season", "year"}

TASK_ID_TOOLS = {
    "get_task", "update_task", "complete_task", "delete_task",
    "skip_task_occurrence", "add_task_comment", "list_task_comments",
    "create_task_relation", "list_task_relations", "remove_task_relation",
}
ENTITY_UID_TOOLS = {
    "get_project", "update_project", "delete_project", "share_project",
    "get_area", "update_area", "delete_area",
    "get_goal", "update_goal", "delete_goal",
    "get_habit", "update_habit", "delete_habit", "log_habit_completion", "skip_habit_period", "get_habit_stats",
    "get_note", "update_note", "delete_note",
    "get_tag", "update_tag", "delete_tag",
    "get_view", "update_view", "delete_view",
    "get_person", "update_person", "delete_person",
    "get_inbox_item", "update_inbox_item", "process_inbox_item", "delete_inbox_item",
}
DELETE_UID_TOOLS = {
    "delete_project", "delete_area", "delete_goal", "delete_habit",
    "delete_note", "delete_person", "delete_tag", "delete_view", "delete_inbox_item",
}


def _safe_stdout(payload: Dict[str, Any]) -> None:
    try:
        raw_bytes = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        sys.stdout.buffer.write(raw_bytes + b"\n")
        sys.stdout.buffer.flush()
    except Exception:
        pass


def _extract_tududi_call(tool_call: Dict[str, Any]) -> tuple[str, Dict[str, Any]]:
    raw_name = str(tool_call.get("name", "") or "")
    raw_args = tool_call.get("arguments") or tool_call.get("args") or {}
    if not isinstance(raw_args, dict):
        raw_args = {}

    if raw_name == "call_mcp_tool":
        srv = str(raw_args.get("ServerName", "") or "").lower()
        if "tududi" in srv:
            inner_tool = str(raw_args.get("ToolName", "") or "")
            inner_args = raw_args.get("Arguments") or {}
            if not isinstance(inner_args, dict):
                inner_args = {}
            return inner_tool, inner_args
        return "", {}

    if "tududi" in raw_name.lower():
        for prefix in ("mcp_tududi_core_", "mcp_tududi-core_", "mcp_tududi_"):
            if raw_name.startswith(prefix):
                return raw_name[len(prefix):], raw_args
        return raw_name, raw_args

    return "", {}


def main() -> None:
    try:
        raw_line = sys.stdin.readline()
        if not raw_line:
            _safe_stdout({"decision": "allow"})
            return

        payload = json.loads(raw_line.strip())
        tool_call = payload.get("toolCall", {})
        tool_name, args = _extract_tududi_call(tool_call)
        if not tool_name:
            _safe_stdout({"decision": "allow"})
            return

        # 1. Task (id) 与其余实体 (uid) 主键字段名混用纠偏守卫
        if tool_name in TASK_ID_TOOLS:
            if (args.get("id") is None or str(args.get("id", "")).strip() == "") and args.get("uid"):
                _safe_stdout({
                    "decision": "deny",
                    "reason": f"TududiGuard 主键纠偏：{tool_name} 的主键参数名为 'id'（而非 'uid'），请将 uid 的值传给参数 'id'。"
                })
                return
        elif tool_name in ENTITY_UID_TOOLS:
            if not str(args.get("uid", "") or "").strip() and args.get("id") is not None:
                _safe_stdout({
                    "decision": "deny",
                    "reason": f"TududiGuard 主键纠偏：{tool_name} 的主键参数名为 15 位字符串 'uid'（而非数字 'id'），请先调用 list_* 获取真实 uid。"
                })
                return
        elif tool_name == "add_subtask":
            if args.get("parent_id") is None or str(args.get("parent_id", "")).strip() == "":
                _safe_stdout({
                    "decision": "deny",
                    "reason": "TududiGuard 参数拦截：add_subtask 必须提供非空 'parent_id'（父任务的 ID 或 UID）。"
                })
                return

        # 2. 高危删除操作主键非空校验
        if tool_name in DELETE_UID_TOOLS:
            if not str(args.get("uid", "") or "").strip():
                _safe_stdout({
                    "decision": "deny",
                    "reason": f"TududiGuard 物理拦截：{tool_name} 必须提供非空 15 位字符串参数 'uid'（请先调用 list_* 查询真实 uid）。"
                })
                return
        elif tool_name == "delete_task":
            if args.get("id") is None or str(args.get("id", "")).strip() == "":
                _safe_stdout({
                    "decision": "deny",
                    "reason": "TududiGuard 物理拦截：delete_task 必须提供非空参数 'id'（任务 ID 或 UID）。"
                })
                return

        # 3. 任务 vs 项目 异构 priority 枚举纠偏拦截
        if tool_name in {"create_task", "update_task", "add_subtask", "create_habit", "update_habit"}:
            prio = args.get("priority")
            if prio is not None and str(prio) not in VALID_TASK_PRIORITY:
                _safe_stdout({
                    "decision": "deny",
                    "reason": f"TududiGuard 参数纠偏：{tool_name} 的 priority 仅支持字符串 'none' | 'low' | 'medium' | 'high'（不支持 '{prio}'，最高优请传 'high'）。"
                })
                return
        elif tool_name in {"create_project", "update_project"}:
            prio = args.get("priority")
            if prio is not None and prio not in VALID_PROJECT_PRIORITY:
                _safe_stdout({
                    "decision": "deny",
                    "reason": f"TududiGuard 参数纠偏：{tool_name} 的 priority 为数字枚举 0(低) | 1(中) | 2(高)，不支持 '{prio}'。"
                })
                return

        # 4. Task / Project / Goal 异构 status 与 horizon 枚举纠偏拦截
        if tool_name in {"update_task", "list_tasks"}:
            st = args.get("status")
            if st is not None and str(st) not in VALID_TASK_STATUS:
                _safe_stdout({
                    "decision": "deny",
                    "reason": f"TududiGuard 参数纠偏：{tool_name} 的 status 仅支持 'not_started' | 'planned' | 'in_progress' | 'waiting' | 'done' | 'cancelled'（不支持 '{st}'）。"
                })
                return
        elif tool_name in {"create_project", "update_project"}:
            st = args.get("status")
            if st is not None and str(st) not in VALID_PROJECT_STATUS:
                _safe_stdout({
                    "decision": "deny",
                    "reason": f"TududiGuard 参数纠偏：{tool_name} 的 status 仅支持 'not_started' | 'planned' | 'in_progress' | 'waiting' | 'done' | 'cancelled'（不支持 '{st}'）。"
                })
                return
        elif tool_name in {"create_goal", "update_goal"}:
            st = args.get("status")
            if st is not None and str(st) not in VALID_GOAL_STATUS:
                _safe_stdout({
                    "decision": "deny",
                    "reason": f"TududiGuard 参数纠偏：{tool_name} 的 status 仅支持 'active' | 'achieved' | 'paused' | 'dropped'（不支持 '{st}'）。"
                })
                return
            hz = args.get("horizon")
            if hz is not None and str(hz) not in VALID_GOAL_HORIZON:
                _safe_stdout({
                    "decision": "deny",
                    "reason": f"TududiGuard 参数纠偏：{tool_name} 的 horizon 仅支持 'season' | 'year'（不支持 '{hz}'）。"
                })
                return

        # 5. 标签防滥用拦截：封杀 today/someday/汇报 与非工种标签
        tags = args.get("tags")
        if isinstance(tags, list):
            bad_tags = [str(t) for t in tags if str(t).lstrip("#@").lower() in FORBIDDEN_TAGS]
            if bad_tags:
                _safe_stdout({
                    "decision": "deny",
                    "reason": f"TududiGuard 标签防滥用拦截：严禁传入时间、动作或状态标签 {bad_tags}！Tududi 系统自带 Defer Until 与 Today 智能四分区，且任务性质严格限定为四正交工种标签（开发/运维/规划/缺陷），请勿重复打时间或汇报标签。"
                })
                return
        if tool_name == "create_tag":
            tname = str(args.get("name", "") or "").lstrip("#@").lower()
            if tname in FORBIDDEN_TAGS:
                _safe_stdout({
                    "decision": "deny",
                    "reason": f"TududiGuard 标签防滥用拦截：严禁创建表示时间、优先级、状态或汇报动作的标签 '{args.get('name')}'！"
                })
                return

        # 6. 任务与子任务标题脱水契约守卫 (Title Ergonomics Guard)
        if tool_name in {"create_task", "update_task", "add_subtask"}:
            name = str(args.get("name", "") or "").strip()
            if name:
                # 检查中括号前缀
                if re.search(r"^\[(运维|规划|开发|缺陷|汇报|待办|测试)\]", name):
                    _safe_stdout({
                        "decision": "deny",
                        "reason": f"TududiGuard 标题脱水拦截：标题 '{name}' 严禁手写 '[运维]' / '[开发]' 等中括号前缀！工种性质必须通过 tags 字段传递，由系统置顶药丸直接呈现。"
                    })
                    return
                # 检查伪编号/软编号 (T04-0004), (TASK-045)
                if re.search(r"[\(\[](T\d+-\d+|TASK-[A-Z0-9\-]+)[\)\]]", name, re.IGNORECASE):
                    _safe_stdout({
                        "decision": "deny",
                        "reason": f"TududiGuard 标题脱水拦截：标题 '{name}' 严禁硬编码历史软编号！Tududi 已有原生全局递增自增 ID 与 UID，历史编号请下沉写入 note 字段的【关联编号】。"
                    })
                    return
                # 检查重复项目名前缀 (如 网格化平台：...)
                if re.search(r"^(O[1-4]-KR\d+|网格化管理平台|干部公寓|物业系统|智能门锁|AI监控|安防监控|滴滴企业打车|园区门户|仓储方案|Tududi)\s*[:：]", name):
                    _safe_stdout({
                        "decision": "deny",
                        "reason": f"TududiGuard 标题脱水拦截：标题 '{name}' 严禁重复项目名称前缀！请直接以 8~18 字精准动宾短语开头（如 '编制业务指引手册与网格员培训'）。"
                    })
                    return

        _safe_stdout({"decision": "allow"})

    except BaseException:
        _safe_stdout({"decision": "allow"})
    finally:
        sys.exit(0)


if __name__ == "__main__":
    main()
