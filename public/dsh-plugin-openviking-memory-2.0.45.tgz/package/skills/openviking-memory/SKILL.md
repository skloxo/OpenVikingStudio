---
name: openviking-memory
description: OpenViking 体外大脑核心记忆操作规范 — 指导 Agent 在开局检索历史经验、执行中精准查阅架构与凭据、任务结束时将关键决策与经验教训持久化回写至 Master Memory。
---

# 🧠 OpenViking 核心记忆操作规范 (openviking-memory)

> **物理第一性原理**：单个会话的上下文容量是有限且易失的，而体外大脑是跨越会话、跨越智能体、跨越物理节点的唯一持久化真相源 (SSOT)。

---

## 一、记忆生命周期循环 (The Recall-Execute-Persist Loop)

```
[任务启动] ──────► [任务推进] ──────► [任务收尾]
    │                    │                  │
    ▼                    ▼                  ▼
openviking_find    openviking_read    openviking_write /
(意图先验召回)      (切片按需深读)     openviking_record_evolution_lesson
```

---

## 二、标准工具调用准则

### 1. 开局先验检索 (`openviking_find`)
- **原则**：面对复杂架构、未知的项目规范或历史设计决策时，优先调用 `openviking_find(query="...")`；
- **目标空间**：系统优先从公共共享层 `viking://resources/master_memory/` 召回高确定性事实；
- **防重复盲搜**：若 Hook 已在调用前注入了相关记忆摘要，直接阅读上下文，禁止相同 query 盲搜。

### 2. 精准按需深入 (`openviking_read` / `openviking_smart_read`)
- **原则**：摘要不足以支撑精准编码时，使用 URI 直接读取完整文件；
- **分层读取**：对于特大文档，可指定分层级别（L0 摘要、L1 骨架、L2 全文），保护工作记忆。

### 3. 永久沉淀回写 (`openviking_write` / `openviking_record_evolution_lesson`)
- **架构决策与规范（防信息孤岛铁律）**：必须写入公共共享域 `viking://resources/master_memory/...`；**严禁**将跨 Agent 通用知识调用 `openviking_store`（会自动创建 `user/<user_id>/sessions/mcp-store-*` 并默认沉淀至按 `user_id` 隔离的 `memories/`）或写入 `viking://~/memories/`，避免同空间其他 Agent 检索不到而形成孤岛；
- **踩坑与故障反思**：调用 `openviking_record_evolution_lesson`，系统自动写入本地技能与 Master Memory 双写存盘，形成智力复利。

### 4. 目录级规则检索与外部 MCP 动态路由 (`openviking_rule_search` / `openviking_find_mcp_tools` / `openviking_invoke_mcp_tool`)
- **规则上下文检索**：在执行目录操作前调用 `openviking_rule_search(task_context=...)`，获取并逐条评估适用规则约束；
- **按需外部 MCP 调用**：先调用 `openviking_find_mcp_tools(query=...)` 获取路由 URI 与参数 Schema，再调用 `openviking_invoke_mcp_tool(tool_uri=..., arguments=...)` 透传执行。

---

## 三、 快思考记忆过滤与算子分工认知 (Fast-Thinking Memory Filter & Rerank SSOT)

1. **快思考记忆层本质**：非自回归单次 Forward 剪枝（0 Token、30ms）。切勿引入外部闭源所谓“System One / Jev”模型，避免网络延迟反噬；
2. **RER 算子唯一源**：记忆检索精排统一由本地 2080Ti 常驻的 `Qwen3-VL-Reranker-2B`（11433 端口 `/v1/rerank`）承接；
3. **JEV 边界分工**：JEV 属流程控制模型（处理 Choice/Bool 决策），不可替代 RER 处理海量长文本与代码规范的语义交叉重排。
