# 📋 Tududi (todo) 全域任务管理与 OKR+GTD 生产力中枢规约契约 (Tududi Agent Rules SSOT)

本规约是全集群智能体（Google Antigravity、DeepSeek Harness、Pi Agent）在涉及任务、待办、项目、习惯、目标与收集箱管理时的常驻潜意识法则。

---

## 一、 意图识别与工具分流第一公理 (Intent Routing Axiom)
1. **自然语言第一反射**：凡人类提及 **“Tududi”、“todo”、“待办”、“任务清单”、“今日任务”、“收集箱 (Inbox)”、“习惯打卡”、“项目进度”、“周报/月报/OKR进度”** 时，必须 **100% 路由至 `tududi` (`tududi_core`) MCP 工具集**，并遵循 `tududi_ops` 技能规范；
2. **职责边界清晰**：
   - **Tududi (`https://todo.tide.red`)**：统管全集群与人类的 **OKR 目标 (Goals)、业务项目 (Projects)、日常/研发任务 (Tasks & Subtasks)、周期习惯 (Habits)、收集箱 (Inbox) 与参考笔记 (Notes)**，是人类网页端零 Token 感知进度与导出周报/月报/OKR 的唯一事实源；
   - **代码仓库 `REFACTORING_PLAN.md`**：仅记录单仓库内部文件级编码微步，模块级与业务级任务一律在 Tududi 统管。

---

## 二、 OKR + GTD 五层标准映射定式 (5-Layer Hierarchy SSOT)
全系统实体严格遵循「上半截管 OKR 战略交账、下半截管 GTD 落地执行」的五层咬合结构，严禁混层：

1. **L1 `Area (领域)` —— 公私最高物理边界（永不结案）**：
   - 全系统仅设 2 个顶级领域：**`工作`** (`id: 6, uid: "bchf3cj1tr44xv7"`) 与 **`个人`** (`id: 7, uid: "f9hshwtupevwy8q"`)。
2. **L2 `Goal (目标)` —— 对应公司年度/季度 OKR 考核大项 (`O`)**：
   - 仅在 `工作` 领域下建立，100% 严格对齐公司提交的 OKR 原文名称：**`O1：数字化产品创新建设`**、**`O2：后勤服务系统建设`**、**`O3：行政办公 AI 辅助系统`**、**`O4：部门例行工作`**（`个人` 领域无需建 OKR 目标）；
   - **严禁加额外括号解释或将软件小迭代版本号建成 Goal**。
3. **L3 `Project (项目)` —— 具体业务系统/专案主体（直接承接核心 `KR` 载体）**：
   - **容器与指标分离定式 (`Project ≈ KR`)**：`Project` 标题与本地目录保持简短清爽（容器名），对应的年度/季度量化 `KR` 验收标准写入 `Goal/Project.description` 与本地 `Ox_.../AGENTS.md`；该项目下所有已完成 Task 的 `【达成成果】` 汇总即构成该条 `KR` 的结案证明；
   - **O1~O4 标准映射**：O1 `网格化管理平台` #1；O2 `干部公寓与世纪华庭` #2；O3 `安防监控中台` #21、`任务调度中枢 (Tududi)` #20、`AI监控` #17；O4 `滴滴企业打车` #16、`园区门户` #19、`仓储方案` #18、`技术运维与例行保障` #15（个人下：`智能体与知识中枢` #4、`CPA 算力网关` #8、`算力集群与运维` #3 等）；
   - **严禁将单个功能开发卡（如 `TASK-042`）提拔建成独立 Project**。
4. **L4 `Tag (标签)` —— 横切区分任务的「工作性质」**：
   - 核心职能标签严格收敛为 5 个：**`规划`**、**`开发`**、**`运维`**、**`汇报`**、**`缺陷`**；
   - **严禁创建或使用表示优先级（如 `P0`、`紧急`）、状态（如 `待办`、`已完成`）或重复领域名的标签**。
5. **L5 `Task ➔ Subtask (两层任务)` —— 落地执行动作**：
   - **常规任务**：`Task` 放功能特性或独立事项（标题带 `[规划]` / `[开发]` / `[运维]` / `[汇报]` / `[缺陷]` 前缀并挂对应 Tag）➔ `Subtask` 放可验收的模块/步骤 ➔ 更细的代码文件级微步写入 `Task.note` 的 Markdown Checklist；
   - **跨周巨型任务**：拆为带 `[专题名 1/N]` 前缀的并列一级 `Task`，通过 `create_task_relation(type="blocks")` 建立先后依赖链，每个 `Task` 下挂各自的 `Subtask`。

---

## 三、 Agent 三大自动作业神经反射 (Three Agent Reflexes)
1. **开局自动领活 (Read on Start)**：新会话提及具体项目或询问下一步任务时，Agent 自动调用 `list_tasks(project_id=..., status="in_progress")` 与 `list_tasks(project_id=..., status="planned")` 盘点当前进度，免除人类翻找文档负担；
2. **过程随手记分支 (Capture on the Fly)**：开发或排障中途发现顺带缺陷、分支问题或新优化点时，不打断当前主线，立即调用 `create_task` 挂入对应 `Project`（设 `status="not_started"`，打 `缺陷` 或 `开发`/`运维` 标签），确保 100% 零遗忘；
3. **完工强制留双行汇报锚点 (Quantified Closure)**：任务达成调用 `complete_task` 前，必须通过 `update_task` 在任务 `note` 中写入结构化交付总结（供周报/月报/OKR 直接抽取）：
   - `【达成成果】`：量化交付物与真实物理锚点（具体模块、接口数、设备数、单测通过数）；
   - `【解决挑战】`：解决的业务痛点、技术难点或理顺的跨部门协同机制。

---

## 四、 65 项 MCP 工具入参异构避坑铁律 (Parameter Contract Guardrails)
1. **主键字段名异构律 (`id` vs `uid`)**：
   - **Task（任务）专属主键为 `id`**：调用 `get_task`、`update_task`、`complete_task`、`delete_task`、`skip_task_occurrence`、`add_task_comment`、`list_task_comments`、`create_task_relation`、`list_task_relations`、`remove_task_relation` 时，主键参数名一律为 **`id`**；`add_subtask` 父任务参数名为 **`parent_id`**；
   - **其余全部实体主键为 `uid`**：调用 Area、Project、Goal、Habit、Inbox、Note、Person、Tag、View 的 `get_*`、`update_*`、`delete_*`、`log_habit_completion`、`process_inbox_item` 时，主键参数名一律为 **`uid`**（15 位字符串）。
2. **外键关联字段律**：
   - `create_task` / `update_task` 绑定项目传 **`project_id`**（数字 ID），绑定领域传 **`area_id`**（数字 ID）或 **`area_uid`**（字符串 UID）；
   - `create_project` / `update_project` 绑定领域传 **`area_id`**（数字 ID），绑定目标传 **`goal_id`**（数字 ID）或 **`goal_uid`**（字符串 UID）；`create_goal` 绑定领域传 **`area_id`**（数字 ID）。
3. **优先级 (`priority`) 类型异构律**：
   - **任务与习惯 (`create_task` / `update_task` / `add_subtask` / `create_habit`)**：`priority` 为**字符串枚举** `"none" | "low" | "medium" | "high"`（🚫 **绝对禁止传 `"urgent"`**）；
   - **项目 (`create_project` / `update_project`)**：`priority` 为**数字枚举** `0` (低)、`1` (中)、`2` (高)。
4. **状态 (`status`) 枚举律**：
   - 任务与项目的 `status` 严格限定为：**`"not_started" | "planned" | "in_progress" | "waiting" | "done" | "cancelled"`**（🚫 **绝对禁止传 `"todo"`**）；
   - 目标 (`Goal`) 的 `status` 限定为：**`"active" | "achieved" | "paused" | "dropped"`**，周期 `horizon` 限定为 **`"season" | "year"`**。
