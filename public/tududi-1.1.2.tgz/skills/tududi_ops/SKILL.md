---
name: tududi_ops
sop_summary: 开局自动领活 (list_tasks) ➔ 五重参数守卫 ➔ 过程随手记分支 ➔ 完工留双行汇报锚点
description: Tududi (todo) 任务管理系统生产级运维、OKR+GTD 五层标准架构、Agent 三大自动作业反射、原生 FastMCP 65 算子实战调用 SOP 与防标签滥用标准化技能 (Tududi Ops & OKR-GTD Governance SOP)。
---

# 📋 Tududi (todo) 全域 OKR+GTD 生产力中枢与 65 算子治理规范 (Tududi Ops SSOT)

> **官方命名与别名契约**：正式名称为 **Tududi**，全集群智能体与日常沟通中通用简称包括 **todo**、**任务清单**、**任务记录**、**待办**、**待办系统**。

---

## 🛡️ 一、 交代底牌律 (Hook Transparency) 与物理拓扑 SSOT

1. **交代底牌律 (`tududi-okr-gtd-guard` PreToolUse 五重守卫)**：宿主已挂载 `tududi_guard.py` 拦截器，在调用工具前静默执行五重校验：1) Task 专属主键 `id` 与其余实体主键 `uid` 混用自动纠偏；2) `delete_*` 空主键物理阻断；3) Task 字符串 `priority` (`"none"|"low"|"medium"|"high"`) 与 Project 数字 `priority` (`0|1|2`) 异构校验；4) 非法 `status`（如 `"todo"`）与 `horizon` 枚举阻断；5) 优先级/状态/顶层领域词充当 Tag 滥用拦截。
2. **宿主与容灾双网端点**：Mac Studio M3 Ultra (`10.128.226.5`) OrbStack 运行 `tududi:latest` + `postgres:16-alpine`（`/Users/fsk/tududi/`，每日 03:00 滚动备份）；公网首选 `https://todo.tide.red/api/mcp`，内网秒级降级 `http://10.128.226.5:3002/api/mcp`；凭据存于本地 KeePass `/Tududi 任务管理系统`。
3. **完工必留双行汇报锚点**：调用 `complete_task` 前，必须先通过 `update_task` 在 `note` 写入 `【达成成果】`（量化交付物与物理锚点）与 `【解决挑战】`（技术难点与跨部门协同），供周报/月报/OKR 直接抽取。

---

## 🧭 二、 OKR + GTD 五层标准映射定式 (5-Layer Hierarchy SSOT)

全系统以 **`Project`（项目）** 为咬合齿轮，上半截管 **OKR 战略交账**，下半截管 **GTD 执行落地**：

| 层级 | Tududi 实体 | 核心职责与边界 | 生产环境标准实例与主键速查 |
| :--- | :--- | :--- | :--- |
| **L1** | **`Area` (领域)** | 公私最高物理边界（永不结案） | • **`工作`** (`id: 6, uid: "bchf3cj1tr44xv7"`)<br>• **`个人`** (`id: 7, uid: "f9hshwtupevwy8q"`) |
| **L2** | **`Goal` (目标)** | **公司 OKR 考核大项 (`O`)**<br>*(仅工作领域设 OKR，严格对齐公司提交名称，不加括号后缀)* | • **`O1：数字化产品创新建设`** (`id: 1, uid: "yr8q4914aczrz51"`, 30%)<br>• **`O2：后勤服务系统建设`** (`id: 5, uid: "wig31qsa8xk2er1"`, 30%)<br>• **`O3：行政办公 AI 辅助系统`** (`id: 6, uid: "gjnfkquxkyv2e2y"`, 20%)<br>• **`O4：部门例行工作`** (`id: 7, uid: "p2id3pvtcf0ag92"`, 20%) |
| **L3** | **`Project` (项目)** | **具体业务系统/专案主体（直接承接核心 `KR` 载体）**<br>*(标题保持简短容器名，量化 KR 写进 description 与本地 `Ox/AGENTS.md`；已完成 Task 的 `【达成成果】` 汇总即等于该条 KR 交账证明)* | • **O1**：`网格化管理平台` (#1)<br>• **O2**：`干部公寓与世纪华庭` (#2)<br>• **O3**：`安防监控中台` (#21)、`任务调度中枢 (Tududi)` (#20)、`AI监控` (#17)<br>• **O4**：`滴滴企业打车` (#16)、`园区门户` (#19)、`仓储方案` (#18)、`技术运维与例行保障` (#15)<br>• **个人**：`智能体与知识中枢` (#4)、`CPA 算力网关` (#8)、`算力集群与运维` (#3)、`自建搜索引擎` (#14)、`节点与代理治理 (3x-ui)` (#10) |
| **L4** | **`Tag` (标签)** | **横切区分任务的「工作性质」**<br>*(禁传 P0/紧急/待办/工作/个人)* | **五大标准职能标签**：**`规划`**、**`开发`**、**`运维`**、**`汇报`**、**`缺陷`** |
| **L5** | **`Task ➔ Subtask`** | **两层可执行动作拆解** | • **常规大任务**：`Task` 放特性（带 `[规划]/[开发]/[运维]/[汇报]/[缺陷]` 前缀）➔ `Subtask` 放可验收模块 ➔ 代码文件级微步写进 `Task.note` Checklist；<br>• **跨周巨型任务**：拆为 `[专题名 1/N]` 并列 `Task`，用 `create_task_relation(type="blocks")` 串联依赖，各挂 `Subtask`。 |

---

## 🤖 三、 Agent 三大自动作业神经反射 (Three Agent Reflexes)

1. **反射 1 · 开局自动领活 (`Read on Start`)**：新会话提及某项目或询问下一步做什么时，立即调用 `list_tasks(project_id=..., status="in_progress")` 与 `list_tasks(project_id=..., status="planned")` 掌握当前主线进度，免除人类翻文档交代背景的负担。
2. **反射 2 · 过程随手记分支 (`Capture on the Fly`)**：开发或排障中途发现顺带缺陷、分支问题或待优化项时，不打断当前主线，立即调用 `create_task` 挂入对应 `Project`（设 `status="not_started"`，挂 `["缺陷"]` 或 `["开发"]` 标签），100% 零遗忘。
3. **反射 3 · 完工强制留双行汇报锚点 (`Quantified Closure`)**：任务完成调用 `complete_task` 前，必须先通过 `update_task` 在 `note` 中写入 `【达成成果】` 与 `【解决挑战】` 双行总结，作为周报、月报、季度/年度 OKR 一键导出的直接数据源。

---

## 🛠️ 四、 65 项 MCP 原生算子分类与异构参数速查

| 实体域 | 算子数 | 核心算子与主键/入参铁律 |
| :--- | :--- | :--- |
| **Task / Subtask** | 12 | `list_tasks`, `get_task`, `create_task`, `update_task`, `complete_task`, `delete_task`, `skip_task_occurrence`, `add_subtask` (`parent_id`), `create/list/remove_task_relation`, `get_task_metrics` — **主键一律用 `id`；`priority`: `"none"\|"low"\|"medium"\|"high"`；`status`: `"not_started"\|"planned"\|"in_progress"\|"waiting"\|"done"\|"cancelled"`** |
| **Comment** | 2 | `list_task_comments(id=...)`, `add_task_comment(id=..., content=...)` — **任务主键用 `id`** |
| **Project (≈KR)** | 5 | `list_projects`, `get_project`, `create_project`, `update_project`, `delete_project` — **主键用 `uid`；关联用 `area_id`、`goal_id`/`goal_uid`；`priority` 为数字 `0\|1\|2`** |
| **Goal (≈O)** | 5 | `list_goals`, `get_goal`, `create_goal`, `update_goal`, `delete_goal` — **主键用 `uid`；关联用 `area_id`；`status`: `"active"\|"achieved"\|"paused"\|"dropped"`；`horizon`: `"season"\|"year"`** |
| **Area / Tag** | 10 | `list/get/create/update/delete_area`, `list/get/create/update/delete_tag` — **主键一律用 `uid`** |
| **Habit** | 8 | `list/get/create/update/delete_habit`, `log_habit_completion`, `get_habit_completions`, `delete_habit_completion`, `get_habit_stats` — **主键一律用 `uid`** |
| **Inbox / Note / View / Person / Search** | 23 | `list_inbox`, `add_to_inbox`, `get/update/process/delete_inbox_item`, `list/get/create/update/delete_note`, `list/get/create/update/delete_view`, `list/get/create/update/delete_person`, `search` — **主键一律用 `uid`** |
